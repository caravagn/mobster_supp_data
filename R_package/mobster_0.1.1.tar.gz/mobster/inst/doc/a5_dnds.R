## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## ---- fig.width=5, fig.height=4-----------------------------------------------
fit = mobster::LUFF76_lung_sample

# Print and plot the model
print(fit$best)
plot(fit$best)

## ---- fig.width=2.5, fig.height=5---------------------------------------------
clusters = Clusters(fit$best)
print(clusters)

## ---- fig.width=3, fig.height=3, warning=FALSE--------------------------------
# Run by cluster and default gene list
dnds_stats = dnds(
  clusters,
  gene_list = NULL
)

## ---- eval=FALSE--------------------------------------------------------------
#  # Not run here
#  dnds_stats = dnds(
#    clusters,
#    mapping = c(`C1` = 'Non-tail', `C2` = 'Non-tail', `Tail` = 'Tail'),
#    gene_list = NULL
#  )

## ---- fig.width=9, fig.height=3, warning=FALSE--------------------------------
# Summary statistics
print(dnds_stats$dnds_summary)

# Table observation countns
print(dnds_stats$dndscv_table)

# Plot
print(dnds_stats$plot)

## -----------------------------------------------------------------------------
# Load the list
data('cancer_genes_dnds', package = 'mobster')

# Each sublist is a list 
print(lapply(cancer_genes_dnds, head))

## ---- eval=FALSE--------------------------------------------------------------
#  # Not run here
#  dnds_stats = dnds(
#    clusters,
#    mapping = c(`C1` = 'Non-tail', `C2` = 'Non-tail', `C3` = 'Non-tail', `Tail` = 'Tail'),
#    gene_list = cancer_genes_dnds$Martincorena_drivers
#  )

## -----------------------------------------------------------------------------
# 2 lung samples
data('LU4_lung_sample', package = 'mobster')
data('LUFF76_lung_sample', package = 'mobster')

## ---- fig.width=9, fig.height=3, warning=FALSE--------------------------------
dnds_multi = dnds(
  rbind(
    Clusters(LU4_lung_sample$best) %>% select(chr, from, ref, alt, cluster) %>% mutate(sample = 'LU4'),
    Clusters(LUFF76_lung_sample$best) %>% select(chr, from, ref, alt, cluster) %>% mutate(sample = 'LUFF76')
  ),
  mapping = c(`C1` = 'Non-tail',  # Pool together all clonal mutations
              `Tail` = 'Tail'     # Pool together all tail mutations),
  )
)

print(dnds_multi$plot)

