## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## ---- message=FALSE, warning=F------------------------------------------------
# Example dataset LU4_lung_sample, downloaded from http://genome.kaist.ac.kr/
print(mobster::LU4_lung_sample$best$data)

## ---- message=FALSE, warning=F------------------------------------------------
dataset = random_dataset(
  seed = 123456789, 
  Beta_variance_scaling = 100    # variance ~ U[0, 1]/Beta_variance_scaling
  )

## ---- fig.width=4, fig.height=3-----------------------------------------------
# Data, in the MOBSTER input format with a "VAF" column.
print(dataset$data)

# The generated model contains the parameters of the Beta components (a and b),
# the shape and scale of the tail, and the mixing proportion. 
print(dataset$model)

# A plot object (ggplot) is available where each data-point is coloured by 
# its generative mixture component. The vertical lines annontate the means of
# the sampled Beta distributions.
print(dataset$plot)

## -----------------------------------------------------------------------------
# Hidden function (:::)
mobster:::template_parameters_fast_setup()

## ---- fig.width=4, fig.height=3-----------------------------------------------
# Fast run with auto_setup = "FAST"
fit = mobster_fit(
  dataset$data,    
  auto_setup = "FAST"
  )

## ---- fig.width=4, fig.height=3-----------------------------------------------
# Print the best model
print(fit$best)

# Print top-3 models
print(fit$runs[[1]]) 
print(fit$runs[[2]])
print(fit$runs[[3]])

## -----------------------------------------------------------------------------
# All assignments
Clusters(fit$best)

# Assignments with LVs probability above 85%
Clusters(fit$best, cutoff_assignment = 0.85)

## ---- fig.width=5, fig.height=4-----------------------------------------------
# Plot the best model
plot(fit$best)

## ---- fig.width=10, fig.height=4----------------------------------------------
cowplot::plot_grid(
  dataset$plot, 
  plot(fit$best), 
  ncol = 2,
  align = 'h')

