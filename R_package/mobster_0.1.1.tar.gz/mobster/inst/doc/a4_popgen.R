## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## -----------------------------------------------------------------------------
data('fit_example', package = 'mobster')
print(fit_example$best)

evolutionary_parameters(fit_example)

