## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- include = FALSE, warning=FALSE, message=FALSE, echo=F-------------------
require(dplyr)
require(tidyr)
require(ggplot2)
require(RColorBrewer)

# Marc's simulation
load('simulationdata.Rdata')

# Fit at generation 17
inp = df %>% filter(d == 17, VAF > 0.05)
x = mobster::mobster_fit(inp, 
                         K = 2, 
                         tail = T, 
                         samples = 1, 
                         parallel = F, 
                         seed = 123, description = "MOBSTER fit")

library(ggmuller)

mydf = df %>% as_tibble() %>%
  rename(Generation = d, Identity = cloneid) %>%
  mutate(Identity = ifelse(Identity == 1, 'Ancestral', 'Subclone')) %>%
  group_by(Generation, Identity) %>%
  summarise(Population = n()) 

Muller_df <- ggmuller::get_Muller_df(data.frame(Parent = 'Ancestral', Identity = 'Subclone'), mydf)

## ---- fig.width=8, fig.height=3, echo=FALSE, warning=FALSE,message=FALSE------
cowplot::plot_grid(
  ggmuller::Muller_pop_plot(Muller_df) + 
    mobster:::my_ggplot_theme() +
    guides(fill = guide_legend('Clone')) +
    labs(title = 'Population size (simulation)', subtitle = "Muller plot (ggmuller)") +
    scale_fill_manual(values = alpha(brewer.pal(2, "Set1"), alpha = .7)) +
    geom_vline(xintercept = 17, linetype = 'dashed', size = .3),
  mobster::plot.dbpmm(x$best) + labs(caption = NULL)
)

