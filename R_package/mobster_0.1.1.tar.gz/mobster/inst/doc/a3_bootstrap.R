## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## ----eval=T, fig.height=4, fig.width=8, message=FALSE, warning=FALSE----------
# Data generation
dataset = random_dataset(
  N = 400, 
  seed = 123, 
  Beta_variance_scaling = 100
  )

# Fit model -- FAST option to speed up the vignette
fit = mobster_fit(dataset$data, auto_setup = 'FAST')

# Composition with cowplot
cowplot::plot_grid(
  dataset$plot, 
  plot(fit$best), 
  ncol = 2, 
  align = 'h') %>%
  print

## ---- fig.width=9, fig.height=9, message=FALSE, warning=FALSE, eval=T---------
# The returned object contains also the list of bootstrap resamples, and the fits.
bootstrap_results = mobster_bootstrap(
  fit$best,
  bootstrap = 'nonparametric',
  n.resamples = 25,
  auto_setup = 'FAST' # forwarded to mobster_fit
  )

## -----------------------------------------------------------------------------
# Resamples are available for inspection as list of lists, 
# with a mapping to record the mutation id of the resample data.
# Ids are row numbers.
print(bootstrap_results$resamples[[1]][[1]] %>% as_tibble())

# Fits are available inside the $fits list
print(bootstrap_results$fits[[1]])
plot(bootstrap_results$fits[[1]])

## -----------------------------------------------------------------------------
print(bootstrap_results$errors)

## ---- fig.width=2, fig.height=3-----------------------------------------------
bootstrap_statistics = bootstrapped_statistics(
  fit$best, 
  bootstrap_results = bootstrap_results
  )

## ---- fig.width=2, fig.height=3-----------------------------------------------
# All bootstrapped values
print(bootstrap_statistics$bootstrap_values)

# The model probability
print(bootstrap_statistics$bootstrap_model)

# The parameter stastics
print(bootstrap_statistics$bootstrap_statistics)

## ---- fig.width=2.5, fig.height=3---------------------------------------------
plot_bootstrap_model_frequency(
  bootstrap_results, 
  bootstrap_statistics
  )

## ---- fig.width=12, fig.height=3----------------------------------------------
# Plot the mixing proportions
mplot = plot_bootstrap_mixing_proportions(
  fit$best, 
  bootstrap_results = bootstrap_results, 
  bootstrap_statistics = bootstrap_statistics
  )

# Plot the tail parameters
tplot = plot_bootstrap_tail(
  fit$best, 
  bootstrap_results = bootstrap_results, 
  bootstrap_statistics = bootstrap_statistics
  )

# Plot the Beta parameters
bplot = plot_bootstrap_Beta(
  fit$best, 
  bootstrap_results = bootstrap_results, 
  bootstrap_statistics = bootstrap_statistics
  )

# Figure
figure = ggpubr::ggarrange(
  mplot,
  tplot,
  bplot,
  ncol = 3, nrow = 1,
  widths = c(.7, 1, 1)
)

print(figure)

## ---- fig.width=5.6, fig.height=5---------------------------------------------

plot_bootstrap_coclustering(
  fit$best, 
  bootstrap_results = bootstrap_results, 
  bootstrap_statistics = bootstrap_statistics
  )

