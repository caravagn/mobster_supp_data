## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## ---- fig.width=5, fig.height=4-----------------------------------------------
# Example data where we have 3 events as drivers
example_data = Clusters(mobster::fit_example$best)

# Drivers annotation (we selected this entries to have nice plots)
drivers_rows = c(2239, 3246, 3800)

example_data$is_driver = FALSE
example_data$driver_label = NA

example_data$is_driver[drivers_rows] = TRUE
example_data$driver_label[drivers_rows] = c("DR1", "DR2", "DR3")

# Fit and print the data
fit = mobster_fit(example_data, auto_setup = 'FAST')

best_fit = fit$best
print(best_fit)

## ---- fig.width=5, fig.height=4-----------------------------------------------
plot(best_fit)

## ---- fig.width=5, fig.height=4-----------------------------------------------
copy_best_fit = best_fit 
copy_best_fit$data$is_driver = FALSE 

plot(copy_best_fit)

## ---- fig.width=5, fig.height=4, warning = FALSE------------------------------
plot(best_fit,
     annotation_extras = 
       data.frame(
         VAF = .35, 
         driver_label = "Something",
         stringsAsFactors = FALSE)
     )

## ---- fig.width=10, fig.height=8, warning = FALSE-----------------------------
ggpubr::ggarrange(
  plot(best_fit, tail_color = "darkorange"),                  # Tail color
  plot(best_fit, beta_colors = c("steelblue", "darkorange")), # Beta colors
  plot(best_fit, cutoff_assignment = .50),                    # Hide mutations based on latent variables 
  plot(best_fit, secondary_axis = "SSE"),               # Add a mirrored y-axis with the % of SSE
  ncol = 2,
  nrow = 2
)

## ---- fig.width=10, fig.height=5----------------------------------------------
ggpubr::ggarrange(
  mobster::plot_latent_variables(best_fit, cutoff_assignment = 0),
  mobster::plot_latent_variables(best_fit, cutoff_assignment = 0.4),
  mobster::plot_latent_variables(best_fit, cutoff_assignment = 0.8),
  mobster::plot_latent_variables(best_fit, cutoff_assignment = 0.97),
  ncol = 4,
  nrow = 1
)

## ---- fig.width=3, fig.height=3-----------------------------------------------
plot_mixing_proportions(best_fit)

## ---- fig.width=3, fig.height=3-----------------------------------------------
plot_NLL(best_fit)

## ---- fig.width=3, fig.height=3-----------------------------------------------
plot_entropy(best_fit)

## ---- fig.width=15, fig.height=4, message=FALSE, warning=FALSE----------------
print(fit$fits.table)

## ---- fig.width=15, fig.height=4, message=FALSE, warning=FALSE----------------
ggpubr::ggarrange(
  plot(fit$runs[[1]]),
  plot(fit$runs[[2]]),
  plot(fit$runs[[3]]),
  ncol = 3, 
  nrow = 1
)

## ---- fig.width=6, fig.height=3-----------------------------------------------
# Goodness of fit (SSE), for the top 3 fits.
plot_gofit(fit, TOP = 3)

## ---- fig.width=4, fig.height=4-----------------------------------------------
plot_fit_scores(fit)

## ---- fig.width=9, fig.height=9, message=FALSE, warning=FALSE-----------------
plot_model_selection(fit, TOP = 5)

## ---- message=F, warning=F, eval=TRUE-----------------------------------------
example_data$is_driver = FALSE

# Get a custom model using trace = TRUE
animation_model = mobster_fit(
  example_data, 
  parallel =  FALSE, 
  samples = 3,
  init = 'random',
  trace = TRUE,
  K = 2,
  tail = TRUE)$best

# Prepare trace, and retain every 5% of the fitting steps
trace = split(animation_model$trace, f = animation_model$trace$step)
steps = seq(1, length(trace), round(0.05 * length(trace)))
  
# Compute a density per step, using the template_density internal function
trace_points = lapply(steps, function(w, x) {
  new.x = x
  new.x$Clusters = trace[[w]]
  
  # Hidden function (:::)
  points = mobster:::template_density(
    new.x,
    x.axis = seq(0, 1, 0.01),
    binwidth = 0.01,
    reduce = TRUE
  )
  points$step = w
  
  points
},
x = animation_model)
  
trace_points = Reduce(rbind, trace_points)
  
# Use plotly to create a ShinyApp
require(plotly)
    
trace_points %>%
  plot_ly(
    x = ~ x,
    y = ~ y,
    frame = ~ step,
    color = ~ cluster,
    type = 'scatter',
    mode = 'markers',
    showlegend = TRUE
  )

