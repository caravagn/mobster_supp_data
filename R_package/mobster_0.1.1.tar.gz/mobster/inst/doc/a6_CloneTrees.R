## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- message=FALSE, warning=F------------------------------------------------
library(mobster)
library(tidyr)
library(dplyr)

## ---- fig.width=5, fig.height=4-----------------------------------------------
# Example data where we annotate 3 events as drivers
example_data = Clusters(mobster::fit_example$best)

# Drivers annotation
drivers_rows = c(2239, 3246, 3800)

example_data$is_driver = FALSE
example_data$driver_label = NA

example_data$is_driver[drivers_rows] = TRUE
example_data$driver_label[drivers_rows] = c("DR1", "DR2", "DR3")

# Fit and print the data
fit = mobster_fit(example_data, auto_setup = 'FAST')

best_fit = fit$best
print(best_fit)

## ---- fig.width=12, fig.height=4, warning=FALSE-------------------------------
# Get the trees, select top-rank
trees = get_clone_trees(best_fit)

## ---- fig.width=12, fig.height=4, warning=FALSE-------------------------------
top_rank = trees[[1]]

# Print with S3 methods from ctree
ctree:::print.ctree(top_rank)

## ---- fig.width=12, fig.height=4, warning=FALSE-------------------------------
# 1) Clone tree
# 2) Input ctree data (here adjusted VAF)
# 3) Clone size barplot
ggpubr::ggarrange(
  ctree::plot.ctree(top_rank),
  ctree::plot_CCF_clusters(top_rank),
  ctree::plot_clone_size(top_rank),
  nrow = 1,
  ncol = 3
)

