## mobster 0.1.0 

* Released the first version oaf the tool.
